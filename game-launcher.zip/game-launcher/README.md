**Note:** Runs on .NET 3.1
In order for this to work you will need to replace all 3 https://downloadlink to your download link in the MainWindow.xaml.cs file. (If you're hosting files on Google Drive you can use [this](https://sites.google.com/site/gdocs2direct/) to convert sharing links into direct-download links.)
Add game folder and version.txt file together in the same folder which is the games download link folder.

Name the images Icon.ico and LauncherBackground.png for the images to show up.

Once all of that is done then you will add this Game Launcher as the main download and everytime you update the game it will auto update from the launcher before the game starts.
Just make sure to change the version.txt file to the correct version so you know that it is updating in the Game Launcher.

This launcher works will any type of game. (Unity, Unreal Engine, Python, ect.)